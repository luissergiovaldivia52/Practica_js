# RepasoM2
Si pueden descarguen en una carpeta y recuerden hacer npm install para descargar las dependencias necesarias para correr el test. Luego necesitaran hacer npm start para revisar su progreso en tiempo real con el navegador. Cualquier duda me contactan
